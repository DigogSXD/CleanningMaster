<div align="center">
  <img  src="" height="auto" width="100%"/>
</div>
  
<p>Bem-vindo ao nosso novo software de otimização de PC! Projetado para simplificar sua vida digital, este software limpa seu computador de arquivos desnecessários, liberando espaço e melhorando o desempenho geral do sistema.</p>

<p>Com apenas alguns cliques, você pode remover arquivos temporários e gerenciar serviços não usados. Diga adeus à lentidão e ao espaço de armazenamento limitado.</p>

<p>Nosso software torna seu PC mais rápido e mais limpo, permitindo que você se concentre no que realmente importa.</p>




## Equipe do Projeto

<center>

<div style="display: flex; flex-direction: row; gap: 15px; flex-wrap: wrap; justify-content: center;" >
    <div>
        <a href="https://github.com/DigogSXD">
                <img style="border-radius: 50%;"         src="https://github.com/DigogSXD.png" width="100px;"/>
                <h5 class="text-center">Diogo Borges de Moura</h5>
        </a>
    </div>
    <div>
        <a href="https://github.com/kaiolucas01">
                <img style="border-radius: 50%;"         src="https://github.com/kaiolucas01.png" width="100px;"/>
                <h5 class="text-center">Kaio Lucas</h5>
        </a>
    </div>
     <div>
        <a href="https://github.com/uscascus">
                <img style="border-radius: 50%;"         src="https://github.com/uscascus.png" width="100px;"/>
                <h5 class="text-center">Lucas Coutinho</h5>
        </a>
    </div>
</div>
    
</center>

## Histórico de Versões

| Versão |    Data    | Descrição         | Autor(es)                                          |
| ------ | :--------: | ----------------- | -------------------------------------------------- |
| 1.0    | 19/02/2026 | Criação da página documentação | [Diogo Borges de Moura](https://github.com/DigogSXD) |