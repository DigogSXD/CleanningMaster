from flask_sqlalchemy import SQLAlchemy
import uuid

db = SQLAlchemy()

class ChaveAtivacao(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    chave = db.Column(db.String(36), unique=True, nullable=False)
    usada = db.Column(db.Boolean, default=False)
