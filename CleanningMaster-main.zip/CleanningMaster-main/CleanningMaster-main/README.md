🚀 CleanningMaster - Otimize seu PC!

🖥️ Seu computador está lento? O CleanningMaster veio para resolver isso! Um software poderoso para otimizar o desempenho do seu PC, remover arquivos inúteis e garantir mais segurança digital.

🔥 Funcionalidades

✅ Limpeza de Arquivos Temporários: Remova arquivos indesejados e libere espaço.

✅ Gerenciamento de Inicialização: Controle quais programas iniciam com o Windows.

✅ Remoção Segura de Arquivos: Apague arquivos de forma permanente e segura.

⚡ Mantenha seu PC rápido e eficiente com o CleanningMaster! 🚀

## Equipe do Projeto
| nome | foto |
| -------- | -------- |
| Diogo Borges |<img src="https://github.com/digogsxd.png" height="75" width="75"> |
| Lucas Coutinho |<img src="https://github.com/uscascus.png" height="75" width="75"> |
| Kaio Lucas |<img src="https://github.com/kaiolucas01.png" height="75" width="75"> |
